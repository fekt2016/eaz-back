const mongoose = require('mongoose');

const OrderItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
    min: 1,
  },
  variant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Variant',
  },
  price: {
    type: Number,
    required: true,
    min: 0,
  },
});

const OrderItems = new mongoose.model('OrderItems', OrderItemSchema);

module.exports = OrderItems;
